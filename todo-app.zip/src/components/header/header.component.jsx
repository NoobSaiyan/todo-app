import React from 'react'
import './header.style.css'

export const Header = () => (
    <div className="text"> ToDo </div>
)